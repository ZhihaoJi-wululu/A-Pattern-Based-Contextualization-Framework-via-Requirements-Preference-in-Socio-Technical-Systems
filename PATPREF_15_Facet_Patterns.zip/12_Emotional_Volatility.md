# Emotional Volatility — Reactive expression in response to explicit provocation

**PATPREF** · **Formal specification** 1.0 · **Pattern** `AP-RD-VOL-01` · **Rule** `MS-VOL-01`

Compare a permitted reactive expression and a neutral response when the original model explicitly represents interpersonal provocation and its attribution.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{vol}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Reactive expression in response to explicit provocation (`MS-VOL-01.primary`)

$$
H_{r,o}\equiv \operatorname{AttributedProvocation}.
$$

$$
B_{r,o}\equiv \operatorname{ReactiveExpression} \land \operatorname{NeutralResponse}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{AttributedProvocation}$ | Outcome-specific prerequisite | The original model explicitly describes the same interpersonal provocation and its attribution. Both implementations satisfy existing conduct, rights, safety, and business constraints. |
| $\operatorname{ReactiveExpression}$ | Difference between complete implementations | The preferred implementation has the person represented by the persona respond to the provocation with a reactive expression that assigns blame. |
| $\operatorname{NeutralResponse}$ | Difference between complete implementations | The comparison implementation gives a neutral, factual response to the same provocation while preserving the same required procedure. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Research on anger and reactivity provides adjacent evidence for a PATPREF design hypothesis limited to responses to explicit provocation in the original model. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Robinson et al. (2020)](https://doi.org/10.1016/j.paid.2020.110130), [Pfeiler et al. (2018)](https://doi.org/10.1016/j.paid.2018.04.045)
