# Intellectual Curiosity — Explanatory understanding and generation of new questions

**PATPREF** · **Formal specification** 1.0 · **Pattern** `AP-IC-REDESIGN-01` · **Rule** `MS-IC-01`

Compare explanatory understanding and independent generation of new questions as distinct modeled outcomes. Each support claim concerns one fixed outcome.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{ic}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Explanatory understanding (`explanatory_understanding`)

$$
H_{r,o}\equiv \mathbf T.
$$

$$
B_{r,o}\equiv \operatorname{Explanation} \land \operatorname{LessExplanation}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

### Independent generation of new questions (`new_question_generation`)

$$
H_{r,o}\equiv \mathbf T.
$$

$$
B_{r,o}\equiv \operatorname{NewQuestions} \land \operatorname{LessQuestionGeneration}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Explanation}$ | Difference between complete implementations | The preferred implementation explicitly provides additional relevant explanation, understanding of the topic, or new knowledge. |
| $\operatorname{LessExplanation}$ | Difference between complete implementations | The comparison implementation provides strictly less explanatory understanding of the same topic. A change of communication channel requires further evidence of an explanatory difference. |
| $\operatorname{NewQuestions}$ | Difference between complete implementations | The preferred implementation explicitly requires the persona to formulate or record meaningful, unanswered new questions independently. Permission to ask questions or a reciprocal question-and-answer exchange needs further evidence of independent question generation. |
| $\operatorname{LessQuestionGeneration}$ | Difference between complete implementations | The comparison implementation provides strictly less independent generation of new questions on the same topic. Assess the same outcome on both sides, even where an alternative offers a different learning activity. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

- **Explanatory understanding** The selected scope itself supplies the original additional relevant explanation or understanding.
- **Independent generation of new questions** The selected scope itself supplies independent formulation or recording of meaningful new unanswered questions.

Apply each outcome separately with its own prerequisite and contrast.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Curiosity research distinguishes acquiring information from independently generating new questions. PATPREF applies related curiosity measures to BFI-2 Intellectual Curiosity through a design hypothesis. Each support claim requires a clear difference in the same outcome, with direct evidence beyond the interaction format. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Kang et al. (2009)](https://doi.org/10.1111/j.1467-9280.2009.02402.x), [Litman (2008)](https://doi.org/10.1016/j.paid.2008.01.014), [Koutstaal et al. (2022)](https://doi.org/10.1038/s41598-022-19694-4)
