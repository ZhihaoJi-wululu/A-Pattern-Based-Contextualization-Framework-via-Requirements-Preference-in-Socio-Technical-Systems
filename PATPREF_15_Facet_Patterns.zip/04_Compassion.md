# Compassion — Relief of need and empathetic care

**PATPREF** · **Formal specification** 1.0 · **Pattern** `AP-COMPASSION-R1` · **Rule** `MS-COMPASSION-01`

Evaluate two outcomes independently for the same beneficiary. One concerns relief of a need stated in the model, and the other concerns an explicitly modeled quality of care.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{compassion}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Relief of a modeled need (`modeled_need_relief`)

$$
H_{r,o}\equiv \operatorname{Beneficiary}\land \operatorname{ModeledNeed}.
$$

$$
B_{r,o}\equiv \operatorname{NeedRelief} \land \operatorname{LessRelief}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

### Modeled quality of empathetic care (`modeled_empathetic_care`)

$$
H_{r,o}\equiv \operatorname{Beneficiary}\land \operatorname{CareQuality}.
$$

$$
B_{r,o}\equiv Q_{\mathrm{care}}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Beneficiary}$ | Outcome-specific prerequisite | The original model explicitly identifies the beneficiary. Both implementations refer to the same person or party. |
| $\operatorname{ModeledNeed}$ | Outcome-specific prerequisite | The original model identifies the beneficiary's need or difficulty and states how assistance, explanation, or accommodation is intended to address it. |
| $\operatorname{NeedRelief}$ | Difference between complete implementations | The preferred implementation provides the relief represented in the original model. |
| $\operatorname{LessRelief}$ | Difference between complete implementations | The comparison implementation provides strictly less relief for the same need and beneficiary while preserving all required services. |
| $\operatorname{CareQuality}$ | Outcome-specific prerequisite | The original model includes an explicit quality of empathy or care for this beneficiary and the contributions associated with that quality. |
| $Q_{\mathrm{care}}$ | Difference between complete implementations | The two complete implementations differ strictly in their local effect on the original care quality. The modeled quality and contributions supply the evidence for this route. |

### Local quality difference

$$
Q_{r,o}\equiv\exists q\in Q_M:
\operatorname{OutcomeMatch}(q,r,o,\theta)\land
\operatorname{LocalSourcesIntact}(q,d)\land
\operatorname{LocalEffect}_M(q,\pi_a,d)\succ_q
\operatorname{LocalEffect}_M(q,\pi_b,d).
$$

The existing quality $q$ must match the fixed outcome. All sources of a compound contribution must lie in the comparison scope. A satisfied break contribution takes precedence over positive contributions. Compare the local effects under the original qualitative semantics and record the global quality truth separately. An indeterminate local effect has value $\mathbf U$.

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

- **Relief of a modeled need** The selected scope itself supplies the original modeled relief for the bound beneficiary and need.
- **Modeled quality of empathetic care** The selected scope itself supplies the original empathetic/caring quality for the bound beneficiary.

Apply each outcome separately with its own prerequisite and contrast.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

BFI-2 Compassion concerns others' well-being and informs the modeled care outcome. FeldmanHall and colleagues' pain-relief experiment supplies adjacent evidence for the identified-need outcome. Both mappings are PATPREF design hypotheses about modeled alternatives. The care-quality outcome can be evaluated independently of evidence about real-world distress or relief. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [FeldmanHall et al. (2015)](https://doi.org/10.1016/j.neuroimage.2014.10.043), [Zhao et al. (2017)](https://doi.org/10.1177/1948550616683018)
