# Trust — Bounded cooperation

**PATPREF** · **Formal specification** 1.0 · **Pattern** `AP-TRUST-R1` · **Rule** `MS-TRUST-01`

Compare an existing opportunity to cooperate with independent handling of the same business activity under equivalent verification and safeguards.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{trust}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Opportunity for bounded cooperation (`MS-TRUST-01.primary`)

$$
H_{r,o}\equiv \operatorname{Safeguards}\land \operatorname{ModelRiskClear}.
$$

$$
B_{r,o}\equiv \operatorname{BoundedCooperation} \land \operatorname{IndependentHandling}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Safeguards}$ | Outcome-specific prerequisite | Both complete implementations preserve the authentication, authorization, information access, and verification requirements in the original model. |
| $\operatorname{ModelRiskClear}$ | Outcome-specific prerequisite | A complete review of the original model finds no record of a relevant identity conflict, verification failure, adverse evidence, or unresolved modeled risk. Use the safeguards established by the model. |
| $\operatorname{BoundedCooperation}$ | Difference between complete implementations | The preferred implementation includes cooperation or joint handling explicitly represented in the original model and within the role's discretion. |
| $\operatorname{IndependentHandling}$ | Difference between complete implementations | The comparison implementation handles the same activity independently or omits the optional cooperation while completing all mandatory work. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself supplies the original bounded cooperation opportunity under the original safeguards.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Research on general trust and judgments of trustworthiness motivates a design hypothesis about cooperation within verified boundaries. Assess the counterpart and required checks using the original model's evidence and safeguards. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Kosugi & Yamagishi (1998)](https://doi.org/10.4992/jjpsy.69.349)
