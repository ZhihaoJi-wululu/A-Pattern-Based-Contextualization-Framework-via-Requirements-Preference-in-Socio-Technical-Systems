# Respectfulness — Consideration of legitimate claims

**PATPREF** · **Formal specification** 1.0 · **Pattern** `AP-RESPECT-R1` · **Rule** `MS-RESPECT-01`

Compare how permitted allocations or interpersonal arrangements account for another party's modeled share, contribution, claim, or need.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{respect}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Consideration of the other party's modeled claim (`MS-RESPECT-01.primary`)

$$
H_{r,o}\equiv \operatorname{Allocation}.
$$

$$
B_{r,o}\equiv \operatorname{Considerate} \land \operatorname{LessConsideration}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Allocation}$ | Outcome-specific prerequisite | The original model identifies an allocation or comparable interpersonal arrangement, the other party, and the claim at issue. Existing rights and mandatory fairness constraints apply. |
| $\operatorname{Considerate}$ | Difference between complete implementations | The preferred implementation gives the modeled claim considerate, non-exploitative treatment. |
| $\operatorname{LessConsideration}$ | Difference between complete implementations | The comparison implementation is a permitted arrangement in which the persona retains a share for themselves and gives strictly less consideration to the same modeled claim. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

The BFI-2 respectfulness construct and research on politeness in allocation decisions inform a design hypothesis about consideration for others' claims within the original allocation rules. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Zhao et al. (2017)](https://doi.org/10.1177/1948550616683018)
