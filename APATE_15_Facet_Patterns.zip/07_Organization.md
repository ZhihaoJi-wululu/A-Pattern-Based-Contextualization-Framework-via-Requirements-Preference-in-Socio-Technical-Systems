# Organization — Additional structure for the same material

**Version** `APATE-Formal-1.0` · **Pattern** `AP-RD-ORG-01` · **Rule** `MS-ORG-01`

Express a tendency toward additional indexing, categorization, or systematic organization of the same material.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{org}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Additional systematic organization (`additional_systematization`)

$$
H_{r,o}\equiv \operatorname{SameMaterial}.
$$

$$
B_{r,o}\equiv \operatorname{AdditionalStructure} \land \operatorname{WithoutIncrement}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{SameMaterial}$ | Outcome-specific prerequisite | Both implementations concern the same material in the same original decision and satisfy all requirements for retaining it. |
| $\operatorname{AdditionalStructure}$ | Difference between complete implementations | The preferred implementation adds structure by indexing, categorizing, or systematically arranging the material. Evidence comes from an original organizational effect or the semantics of an action on that material. Reading an indexing manual or using a parameter named `index` requires further evidence of actual organization. |
| $\operatorname{WithoutIncrement}$ | Difference between complete implementations | The comparison implementation lacks the specific additional structure on the same material. Chronological and receipt-order filing count as forms of organization. A strict contrast requires a meaningful increment over the comparison implementation. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself performs the original additional indexing, categorization or systematic organization on the bound material.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Soto and John ground the disposition toward order and structure. APATE operationalizes it through additional modeled indexing or categorization. A reviewed grammar that identifies the action and the material it acts on can establish the task-level difference without a global quality binding. The evidence must establish an organizational action, such as indexing the material itself. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096)
