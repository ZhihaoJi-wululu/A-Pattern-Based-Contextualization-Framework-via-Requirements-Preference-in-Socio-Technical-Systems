# Responsibility — Fulfillment of a modeled commitment

**Version** `APATE-Formal-1.0` · **Pattern** `AP-RD-RES-01` · **Rule** `MS-RES-01`

Express a tendency to fulfill a commitment explicitly attributed to the persona within a permitted optional scope.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{opt}}(p,M,u)$ | An original optional scope. Exactly one role bound to the persona has decision authority, and at least one feasible pair of complete executions compares participation and omission with the same conditions outside the scope. |
| Problem | $D_{\mathrm{res}}(p)\land H_{r,o}\land U_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land U\land\Delta\Rightarrow \operatorname{Support}(r,o,p,\operatorname{sometime}(u))$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Fulfillment of the persona's own modeled commitment (`MS-RES-01.primary`)

$$
H_{r,o}\equiv \operatorname{OwnCommitment}\land \operatorname{CommitmentOpen}.
$$

$$
B_{r,o}\equiv \operatorname{FulfilsCommitment} \land \operatorname{LegitimateOmission}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{OwnCommitment}$ | Outcome-specific prerequisite | The original model explicitly records a commitment or accepted obligation belonging to the persona or the persona's role, along with its subject. A general update or an extra task needs explicit evidence of a commitment. |
| $\operatorname{CommitmentOpen}$ | Outcome-specific prerequisite | The comparison concerns the same outstanding commitment. A review of the original model establishes that it has no record of cancellation, release, or fulfillment through another channel. |
| $\operatorname{FulfilsCommitment}$ | Difference between complete implementations | The complete implementation that includes the original optional scope delivers the modeled outcome of fulfilling that commitment. |
| $\operatorname{LegitimateOmission}$ | Difference between complete implementations | The complete implementation that omits the same scope is feasible and preserves all mandatory work while leaving the commitment unfulfilled within that implementation. |

## Permitted instantiations

- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself supplies fulfillment of the bound original commitment attributable to the persona.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

The Responsibility facet and field research on keeping one's word motivate a modeled preference to fulfill an already represented commitment. The conclusion concerns a design preference for the specified optional activity. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Kanngiesser et al. (2023)](https://doi.org/10.3389/fpsyg.2023.1097239)
