# Assertiveness — Stating a position in a negotiable arrangement

**Version** `APATE-Formal-1.0` · **Pattern** `AP-ASSERT-R1` · **Rule** `MS-ASSERT-01`

Express the persona's own position, boundary, or acceptable alternative in an arrangement that the original model leaves open to negotiation.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{assert}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Expression of one's own position (`MS-ASSERT-01.primary`)

$$
H_{r,o}\equiv \operatorname{Negotiable}.
$$

$$
B_{r,o}\equiv \operatorname{OwnPosition} \land \operatorname{PassiveAcceptance}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Negotiable}$ | Outcome-specific prerequisite | The original model explicitly identifies the same request or arrangement as negotiable and permits the persona to voice a position. Mandatory instructions remain binding. |
| $\operatorname{OwnPosition}$ | Difference between complete implementations | The preferred implementation lets the persona state their own position, set a boundary, or propose a permitted alternative arrangement. |
| $\operatorname{PassiveAcceptance}$ | Difference between complete implementations | The comparison implementation accepts the same negotiable arrangement without expressing the persona's position. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Research on assertiveness and its interpersonal trade-offs motivates a design hypothesis about opportunities to state a position. The modeled distinction is whether a person voices their position in the same arrangement. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Ames & Flynn (2007)](https://doi.org/10.1037/0022-3514.92.2.307), [Breil et al. (2022)](https://doi.org/10.3390/jintelligence10030048)
