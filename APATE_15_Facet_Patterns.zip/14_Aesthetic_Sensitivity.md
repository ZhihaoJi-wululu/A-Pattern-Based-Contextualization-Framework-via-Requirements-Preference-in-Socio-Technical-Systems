# Aesthetic Sensitivity — Sustained appreciation of artistic content

**Version** `APATE-Formal-1.0` · **Pattern** `AP-AS-REDESIGN-01` · **Rule** `MS-AS-01`

Express a tendency toward sustained appreciation when the original model includes artistic content and an opportunity to engage with it.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{as}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Sustained appreciation of artistic content (`MS-AS-01.primary`)

$$
H_{r,o}\equiv \operatorname{ArtisticContent}\land \operatorname{NoRecordedAversion}.
$$

$$
B_{r,o}\equiv \operatorname{SustainedAppreciation} \land \operatorname{LessAppreciation}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{ArtisticContent}$ | Outcome-specific prerequisite | The original model identifies artistic, musical, literary, or explicitly aesthetic content. Decorative software presentation requires separate evidence of qualifying content. |
| $\operatorname{NoRecordedAversion}$ | Outcome-specific prerequisite | A complete review of the persona and model finds no explicit aversion to the specific content. The check concerns this content alone. |
| $\operatorname{SustainedAppreciation}$ | Difference between complete implementations | The preferred implementation offers a sustained opportunity to appreciate the content. |
| $\operatorname{LessAppreciation}$ | Difference between complete implementations | The comparison implementation fulfills the same required purpose and offers strictly less additional exposure to or appreciation of the artistic content. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself supplies sustained appreciation of the bound genuinely artistic/aesthetic content.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Research on aesthetic experience and related openness traits motivates a design hypothesis about optional artistic engagement. The hypothesis concerns the specific content and engagement opportunity represented in the model. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Fayn et al. (2015)](https://doi.org/10.3389/fpsyg.2015.01877), [Castellotti et al. (2025)](https://doi.org/10.1371/journal.pone.0332321)
