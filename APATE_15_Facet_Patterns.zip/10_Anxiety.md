# Anxiety — Noninstrumental advance information

**Version** `APATE-Formal-1.0` · **Pattern** `AP-RD-ANX-01` · **Rule** `MS-ANX-01`

Express a tendency toward an accurate preview when advance information leaves the business decision and final outcome unchanged.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{anx}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Early knowledge of an unchanged outcome (`MS-ANX-01.primary`)

$$
H_{r,o}\equiv \operatorname{Noninstrumental}\land \operatorname{AccuratePreview}.
$$

$$
B_{r,o}\equiv \operatorname{EarlyKnowledge} \land \operatorname{WaitSameOutcome}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Noninstrumental}$ | Outcome-specific prerequisite | The original model explicitly describes early knowledge of the same future outcome. The business decision and final outcome are identical with or without the preview. |
| $\operatorname{AccuratePreview}$ | Outcome-specific prerequisite | The original model itself establishes the accuracy of the preview. |
| $\operatorname{EarlyKnowledge}$ | Difference between complete implementations | The preferred implementation lets the persona learn the same outcome earlier than the comparison implementation. |
| $\operatorname{WaitSameOutcome}$ | Difference between complete implementations | The comparison implementation waits for the usual announcement of the same outcome or omits the optional preview. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself supplies the original accurate earlier knowledge of the same unchanged eventual outcome.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Research on anxiety-related valuation of noninstrumental information motivates a limited early-knowledge design hypothesis about the same modeled outcome. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Bennett et al. (2021)](https://doi.org/10.1037/xge0000966)
