# Productiveness — Completing current work before switching

**Version** `APATE-Formal-1.0` · **Pattern** `AP-RD-PRO-01` · **Rule** `MS-PRO-01`

When both orders are feasible, express a tendency to finish explicitly modeled work already underway or remaining before making a nonurgent switch that the persona may defer.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{tmp}}(p,M,u,v)$ | Two distinct original activities occur in both complete executions. The persona has discretion over their order, and both orders are feasible with the same selected nodes, OR choices, and relative order outside the two activities. |
| Problem | $D_{\mathrm{pro}}(p)\land H_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\Rightarrow \operatorname{Support}(r,o,p,\operatorname{precedes}(u,v))$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Completion of current work before switching (`MS-PRO-01.primary`)

$$
H_{r,o}\equiv \operatorname{StartedRemaining}\land \operatorname{NonurgentDiversion}.
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{StartedRemaining}$ | Outcome-specific prerequisite | The original model explicitly identifies $u$ as current work already underway or as the work that remains. The current-work status requires original model evidence. |
| $\operatorname{NonurgentDiversion}$ | Outcome-specific prerequisite | The original model explicitly identifies $v$ as a nonurgent diversion that the person represented by the persona may defer. |

## Permitted instantiations

- **Temporal** Under $C^{\mathrm{tmp}}$ and the stated $H_{r,o}$, $\operatorname{precedes}(u,v)$ favors complete executions in which $\operatorname{finish}(u)<\operatorname{start}(v)$. The comparison also requires a feasible complete execution with $\operatorname{finish}(v)<\operatorname{start}(u)$.

A `Remaining` child of a `Started` container may serve as an equivalent endpoint when it is the only explicitly remaining unit and every other task in the container precedes the diversion through original `pre` paths. Retain both original IDs and the evidence for those paths.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Research on persistence and effort motivates the design hypothesis about continuity of work. This temporal preference relies on the original model's explicit account of work already underway. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Bates (2024)](https://doi.org/10.1016/j.paid.2024.112690)
