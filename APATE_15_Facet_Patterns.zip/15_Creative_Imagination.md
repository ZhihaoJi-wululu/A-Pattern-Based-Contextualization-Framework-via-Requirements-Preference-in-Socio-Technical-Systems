# Creative Imagination — Generating alternatives for an open-ended problem

**Version** `APATE-Formal-1.0` · **Pattern** `AP-CI-REDESIGN-01` · **Rule** `MS-CI-01`

Express a tendency to participate in generating alternatives for an open-ended problem with multiple permissible possibilities.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{ci}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Generation of alternative ideas (`MS-CI-01.primary`)

$$
H_{r,o}\equiv \operatorname{OpenProblem}\land \operatorname{ReviewPreserved}.
$$

$$
B_{r,o}\equiv \operatorname{Ideation} \land \operatorname{LessIdeation}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{OpenProblem}$ | Outcome-specific prerequisite | The same problem in the original model admits multiple acceptable possibilities and includes an actual ideation activity. |
| $\operatorname{ReviewPreserved}$ | Outcome-specific prerequisite | The original conditions continue to govern independent review, screening, and implementation approval. Ideation, review, and adoption retain their distinct decision rights. |
| $\operatorname{Ideation}$ | Difference between complete implementations | The preferred implementation offers the person represented by the persona an opportunity to generate alternative ideas or explore multiple permissible possibilities. |
| $\operatorname{LessIdeation}$ | Difference between complete implementations | The comparison implementation uses an already qualified baseline or offers strictly less ideation while preserving the same required review. |

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself supplies persona-attributed generation of alternative concepts for the original open problem, with the original review preserved.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Evidence basis

Studies of possibility thinking and divergent production motivate a design hypothesis about participation in ideation. Its scope is the opportunity to generate alternatives, and evaluation and adoption follow the original review conditions. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Glăveanu et al. (2024)](https://doi.org/10.1177/27538699241241827), [Friis-Olivarius & Christensen (2019)](https://doi.org/10.3389/fpsyg.2019.00355)
