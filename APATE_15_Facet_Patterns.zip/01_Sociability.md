# Sociability — Reciprocal interpersonal contact

**Version** `APATE-Formal-1.0` · **Pattern** `AP-SOC-R1` · **Rule** `MS-SOC-01`

Express the persona's tendency toward reciprocal interpersonal contact when comparing complete implementations of the same business goal.

| Element | Formal definition | Explanation |
| --- | --- | --- |
| Context | $C^{\mathrm{ch}}(p,M,G,x,y)$ | Two distinct direct children of the same original OR goal. Exactly one role bound to the persona has decision authority, and at least one pair of feasible complete executions shares the same conditions outside the decision. |
| Problem | $D_{\mathrm{soc}}(p)\land H_{r,o}\land\Delta_{r,o}$ | The original persona identifies the facet and provides evidence of its usual disposition. The modeled outcome must satisfy the applicable conditions below. |
| Solution | $D\land C\land H\land\Delta\Rightarrow \operatorname{Support}(r,o,p,x\succ^G y)$ | When the full conjunction evaluates to $\mathbf T$, record qualitative support for the stated rule and outcome. |

## Outcomes and predicates

### Reciprocal interpersonal contact (`MS-SOC-01.primary`)

$$
H_{r,o}\equiv \mathbf T.
$$

$$
B_{r,o}\equiv (\operatorname{Reciprocal} \land \operatorname{NoEquivalentContact}) \lor Q_{\mathrm{soc}}.
$$

$$
\Delta_{r,o}\equiv\forall(\pi_a,\pi_b)\in\mathcal P_M(d,a,b):B_{r,o}(p,M,d,a,b,\pi_a,\pi_b,\theta).
$$

| Predicate | Role | Condition and original evidence |
| --- | --- | --- |
| $\operatorname{Reciprocal}$ | Difference between complete implementations | The preferred implementation gives the person represented by the persona a genuine opportunity to ask questions and respond in an interpersonal exchange. The source model must attribute the interaction to that person or explicitly offer them the opportunity. A transcript, channel name, or description of joint work requires corroborating evidence of reciprocal contact. |
| $\operatorname{NoEquivalentContact}$ | Difference between complete implementations | The comparison implementation has explicit evidence of lower reciprocity, such as one-way notification or independent written handling. The evidence must establish the absence of interpersonal contact equivalent to that in the preferred implementation. |
| $Q_{\mathrm{soc}}$ | Difference between complete implementations | The original OR goal has an existing quality that explicitly represents reciprocal interpersonal contact. The local quality contributions establish a strict difference under the original qualitative semantics. This route applies to choice, and optional participation requires reciprocal contact within the optional scope itself. |

### Local quality difference

$$
Q_{r,o}\equiv\exists q\in Q_M:
\operatorname{OutcomeMatch}(q,r,o,\theta)\land
\operatorname{LocalSourcesIntact}(q,d)\land
\operatorname{LocalEffect}_M(q,\pi_a,d)\succ_q
\operatorname{LocalEffect}_M(q,\pi_b,d).
$$

The existing quality $q$ must match the fixed outcome. All sources of a compound contribution must lie in the comparison scope. A satisfied break contribution takes precedence over positive contributions. Compare the local effects under the original qualitative semantics and record the global quality truth separately. An indeterminate local effect has value $\mathbf U$.

## Permitted instantiations

- **Choice** Set $(d,a,b)=(G,x,y)$ under $C^{\mathrm{ch}}$. The conclusion $x\succ_p^G y$, written $\operatorname{preferred\_to}(G,x,y)$, favors $x$ over $y$ among the original direct children of $G$.
- **Optional participation** Set $(d,a,b)=(u,1,0)$ for original optional scope $u$, where $1$ denotes participation and $0$ denotes omission. $C^{\mathrm{opt}}$ requires one authorized persona role and at least one feasible participation–omission pair with the same conditions outside $u$. When $D\land C\land H\land U\land\Delta$ is true, $\operatorname{sometime}(u)$ favors complete executions that include $u$.

$U_{r,o}$ requires the following condition in every feasible complete execution that includes $u$, including executions outside the matched pairs.

The selected scope itself supplies reciprocal interpersonal contact for the persona.

## Notation

Let $p$ be the original persona, $M$ the original goal model, $r$ the rule, and $o$ one fixed outcome of the rule. $D_f(p)$ requires facet $f$ to be selected for $p$ and the original persona text to support the corresponding usual disposition. $H_{r,o}$ gives the prerequisites for outcome $o$. Bind each modeled fact to its original evidence.

For a decision $d$, $\mathcal P_M(d,a,b)$ contains pairs $(\pi_a,\pi_b)$ of feasible complete executions that select the compared values $a$ and $b$. A pair agrees on selected nodes, OR choices, and relative task order outside the decision scope. A complete execution satisfies the original mandatory goals, refinements, and stated hard constraints. $\theta$ binds the relevant entities and evidence from the original inputs.

Decision authority comes from original ownership or an explicit grant of discretion. Attribute activities to the person represented by the persona using the original model.

Evaluate conditions using strong Kleene three-valued logic. $\mathbf T$, $\mathbf F$, and $\mathbf U$ mean supported, contradicted, and undetermined. A universal comparison requires complete coverage of the relevant executions and evidence.

## Example

Under the original OR goal `g_contact`, `g_dialogue` includes reciprocal consultation and confirmation. `t_written` involves reading verified written instructions without a conversation. The source persona describes someone who generally enjoys conversations in which both people take part. With an authorized role and matching conditions outside the decision, binding $(G,x,y)=(\texttt{g\_contact},\texttt{g\_dialogue},\texttt{t\_written})$ yields support under `MS-SOC-01.primary` for `g_dialogue` over `t_written`.

## Evidence basis

The BFI-2 defines the sociability disposition, and studies of social interaction show that context shapes its expression. The preference for a modeled reciprocal channel is an APATE design hypothesis. [Soto & John (2017)](https://doi.org/10.1037/pspp0000096), [Breil et al. (2019)](https://doi.org/10.1525/collabra.170), [Breil et al. (2022)](https://doi.org/10.3390/jintelligence10030048)
