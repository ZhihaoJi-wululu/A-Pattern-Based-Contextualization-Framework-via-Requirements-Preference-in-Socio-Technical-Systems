# PATPREF Expert Evaluation Materials

## Completed Expert Responses

These English transcriptions record the independent answers submitted by three experts. Each file contains 37 RQ1 judgments, 40 RQ2 ratings, and translated written comments where provided.

| Reviewer | RQ1 accepted | RQ1 rejected |
| --- | ---: | ---: |
| [E1](expert-responses/PATPREF-Expert-E1-Responses.docx) | 37 | 0 |
| [E2](expert-responses/PATPREF-Expert-E2-Responses.docx) | 35 | 2 |
| [E3](expert-responses/PATPREF-Expert-E3-Responses.docx) | 36 | 1 |

The two CSV files contain the same recorded responses in long form for analysis.

## Assessment Instruments and Data

| Document | Contents |
| --- | --- |
| [Expert evaluation guide](PATPREF-Expert-Evaluation-Guide.docx) | Reading order, notation, judgment criteria, and response instructions. |
| [Expert assessment form](PATPREF-Expert-Assessment-Form.docx) | The 37 RQ1 explanation items and the four RQ2 ratings for each of ten cases, in the original assessment order. |
| [Pattern reference](PATPREF-Pattern-Reference.docx) | Shared conditions, 13 facet sections, and the index connecting 36 relations to the RQ1 items. |
| [Calibration cases](PATPREF-Expert-Calibration-Cases.docx) | The five practice cases, discussion questions, and 1–5 score anchors for each RQ2 dimension. |
| [Anonymized RQ1 judgments](RQ1-Anonymized-Judgments.csv) | 111 judgments with the reviewers' comments in English where provided. |
| [Anonymized RQ2 ratings](RQ2-Anonymized-Ratings.csv) | 120 scores, with one row per reviewer, case, and dimension. |

The assessment form refers to the SVG models in `PATPREF-Contextualized-Examples.zip` by case ID. The calibration document presents its practice models in text.
